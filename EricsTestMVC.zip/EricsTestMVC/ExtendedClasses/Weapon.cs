﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EricsTestMVC.Models
{
    public partial class Weapon
    {
        //this extends the Weapon EF base class

    }
}